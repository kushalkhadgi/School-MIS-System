import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:schoolmis/teacher/edit_studentprofile.dart';

class ProfileScreen extends StatefulWidget {
  final String studentName;

  ProfileScreen({required this.studentName});

  @override
  _ProfileScreenState createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  late TextEditingController _nameController;
  late TextEditingController _emailController;
  late TextEditingController _bloodGroupController;
  late TextEditingController _fathernamecontroller;
  late TextEditingController _mothernameController;
  late TextEditingController _adharController;
  late TextEditingController _addressController;
  late TextEditingController _genderController;
  late TextEditingController _dobController;
  late TextEditingController _occupationController;
  late TextEditingController _gradeController;
  late TextEditingController _parentemailController;
  late TextEditingController _rollnoController;
  late TextEditingController _aim;
  late TextEditingController _placeofbirthController;
  late TextEditingController _religionController;
  late TextEditingController _casteController;
  late TextEditingController _dateofadmissionController;
  late TextEditingController _previouspercentageController;
  late TextEditingController _mobilenumberController;
  late TextEditingController _useridController;
  late TextEditingController _schoolregidController;

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController(text: widget.studentName);
    _emailController = TextEditingController();
    _bloodGroupController = TextEditingController();
    _fathernamecontroller = TextEditingController();
    _mothernameController = TextEditingController();
    _adharController = TextEditingController();
    _addressController = TextEditingController();
    _genderController = TextEditingController();
    _dobController = TextEditingController();
    _occupationController = TextEditingController();
    _gradeController = TextEditingController();
    _parentemailController = TextEditingController();
    _rollnoController = TextEditingController();
    _aim = TextEditingController();
    _placeofbirthController = TextEditingController();
    _religionController = TextEditingController();
    _casteController = TextEditingController();
    _dateofadmissionController = TextEditingController();
    _previouspercentageController = TextEditingController();
    _mobilenumberController = TextEditingController();
    _useridController = TextEditingController();
    _schoolregidController = TextEditingController();

    _fetchAdditionalData();
  }

  void _fetchAdditionalData() {
    FirebaseFirestore.instance
        .collection('users')
        .where('name', isEqualTo: widget.studentName)
        .get()
        .then((QuerySnapshot querySnapshot) {
      if (querySnapshot.docs.isNotEmpty) {
        final userData =
            querySnapshot.docs.first.data() as Map<String, dynamic>;
        setState(() {
          _emailController.text = userData['email'] ?? '';
          _bloodGroupController.text = userData['bloodgroup'] ?? '';
          _fathernamecontroller.text = userData['fathername'] ?? '';
          _mothernameController.text = userData['mothername'] ?? '';
          _adharController.text = userData['adhar'] ?? '';
          _addressController.text = userData['address'] ?? '';
          _genderController.text = userData['gender'] ?? '';
          _dobController.text = userData['dob'] ?? '';
          _occupationController.text = userData['occupation'] ?? '';
          _gradeController.text = userData['grade'] ?? '';
          _parentemailController.text = userData['parentemail'] ?? '';
          _rollnoController.text = userData['rollno'] ?? '';
          _aim.text = userData['aim'] ?? '';
          _placeofbirthController.text = userData['placeofbirth'] ?? '';
          _religionController.text = userData['religion'] ?? '';
          _casteController.text = userData['caste'] ?? '';
          _dateofadmissionController.text = userData['dateofadmission'] ?? '';
          _previouspercentageController.text =
              userData['previouspercentage'] ?? '';
          _mobilenumberController.text = userData['mobilenumber'] ?? '';
          _useridController.text = userData['userid'] ?? '';
          _schoolregidController.text = userData['schoolregid'] ?? '';
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Profile',
        style: TextStyle(
            color: Colors.white, // Set the text color to white
            fontSize: 20, // Adjust the font size if needed
          ),
        ),
        backgroundColor: Colors.deepPurple, // Change the color of the AppBar
        iconTheme: IconThemeData(color: Colors.white),
      ),
      body: SingleChildScrollView(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                buildProfileDetailCard('Name', widget.studentName),
                buildProfileDetailCard('Email', _emailController.text),
                buildProfileDetailCard(
                    'Blood Group', _bloodGroupController.text),
                buildProfileDetailCard(
                    'Father Name', _fathernamecontroller.text),
                buildProfileDetailCard(
                    'Mother Name', _mothernameController.text),
                buildProfileDetailCard('Adhar Number', _adharController.text),
                buildProfileDetailCard('Address', _addressController.text),
                buildProfileDetailCard('Gender', _genderController.text),
                buildProfileDetailCard('Date of Birth', _dobController.text),
                buildProfileDetailCard(
                    'Occupation', _occupationController.text),
                buildProfileDetailCard('Class', _gradeController.text),
                buildProfileDetailCard(
                    'Parent Email', _parentemailController.text),
                buildProfileDetailCard('Roll Number', _rollnoController.text),
                buildProfileDetailCard(
                    'Place of Birth', _placeofbirthController.text),
                buildProfileDetailCard('Religion', _religionController.text),
                buildProfileDetailCard('Caste', _casteController.text),
                buildProfileDetailCard(
                    'Date of Admission', _dateofadmissionController.text),
                buildProfileDetailCard(
                    'Previous Percentage', _previouspercentageController.text),
                buildProfileDetailCard(
                    'Mobile Number', _mobilenumberController.text),
                buildProfileDetailCard('User ID', _useridController.text),
                buildProfileDetailCard(
                    'School Registration ID', _schoolregidController.text),
                SizedBox(height: 16), // Add some spacing
                Center(
                  child: ElevatedButton(
                    onPressed: _navigateToEditProfile,
                    child: Text('Edit Profile'),
                  ),
                ),

              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget buildProfileDetailCard(String label, String value) {
    return Container(
      width: double.infinity,
      margin: EdgeInsets.symmetric(vertical: 8),
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        
        borderRadius: BorderRadius.circular(8),
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            // color: const Color.fromARGB(255, 158, 158, 158).withOpacity(0.5),
            spreadRadius: 2,
            blurRadius: 5,
            offset: Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: TextStyle(
              fontSize: 14,
            ),
          ),
          SizedBox(height: 8),
          Text(
            value,
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  void _navigateToEditProfile() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => EditProfileScreen(
          studentName: widget.studentName,
          email: _emailController.text,
          bloodGroup: _bloodGroupController.text,
          fathername: _fathernamecontroller.text,
          mothername: _mothernameController.text,
          adhar: _adharController.text,
          address: _addressController.text,
          gender: _genderController.text,
          dob: _dobController.text,
          occupation: _occupationController.text,
          grade: _gradeController.text,
          parentemail: _parentemailController.text,
          rollno: _rollnoController.text,
          placeofbirth: _placeofbirthController.text,
          religion: _religionController.text,
          caste: _casteController.text,
          dateofadmission: _dateofadmissionController.text,
          previouspercentage: _previouspercentageController.text,
          mobilenumber: _mobilenumberController.text,
          userid: _useridController.text,
          schoolregid: _schoolregidController.text,
        ),
      ),
    );
  }
}
