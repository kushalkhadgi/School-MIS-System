import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:schoolmis/teacher/studentdetails_screen.dart';

class EditProfileScreen extends StatefulWidget {
  final String studentName;
  final String email;
  final String bloodGroup;
  final String fathername;
  final String mothername;
  final String adhar;
  final String address;
  final String gender;
  final String dob;
  final String occupation;
  final String grade;
  final String parentemail;
  final String rollno;
  final String placeofbirth;
  final String religion;
  final String caste;
  final String dateofadmission;
  final String previouspercentage;
  final String mobilenumber;
  final String userid;
  final String schoolregid;

  EditProfileScreen({
    required this.studentName,
    required this.email,
    required this.bloodGroup,
    required this.fathername,
    required this.mothername,
    required this.adhar,
    required this.address,
    required this.gender,
    required this.dob,
    required this.occupation,
    required this.grade,
    required this.parentemail,
    required this.rollno,
    required this.placeofbirth,
    required this.religion,
    required this.caste,
    required this.dateofadmission,
    required this.previouspercentage,
    required this.mobilenumber,
    required this.userid,
    required this.schoolregid,
  });

  @override
  _EditProfileScreenState createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  late TextEditingController _nameController;
  late TextEditingController _emailController;
  late TextEditingController _bloodGroupController;
  late TextEditingController _fathernameController;
  late TextEditingController _mothernameController;
  late TextEditingController _adharController;
  late TextEditingController _addressController;
  late TextEditingController _genderController;
  late TextEditingController _dobController;
  late TextEditingController _occupationController;
  late TextEditingController _gradeController;
  late TextEditingController _parentemailController;
  late TextEditingController _rollnoController;
  late TextEditingController _placeofbirthController;
  late TextEditingController _religionController;
  late TextEditingController _casteController;
  late TextEditingController _dateofadmissionController;
  late TextEditingController _previouspercentageController;
  late TextEditingController _mobilenumberController;
  late TextEditingController _useridController;
  late TextEditingController _schoolregidController;

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController(text: widget.studentName);
    _emailController = TextEditingController(text: widget.email);
    _bloodGroupController = TextEditingController(text: widget.bloodGroup);
    _fathernameController = TextEditingController(text: widget.fathername);
    _mothernameController = TextEditingController(text: widget.mothername);
    _adharController = TextEditingController(text: widget.adhar);
    _addressController = TextEditingController(text: widget.address);
    _genderController = TextEditingController(text: widget.gender);
    _dobController = TextEditingController(text: widget.dob);
    _occupationController = TextEditingController(text: widget.occupation);
    _gradeController = TextEditingController(text: widget.grade);
    _parentemailController = TextEditingController(text: widget.parentemail);
    _rollnoController = TextEditingController(text: widget.rollno);

    _placeofbirthController = TextEditingController(text: widget.placeofbirth);
    _religionController = TextEditingController(text: widget.religion);
    _casteController = TextEditingController(text: widget.caste);
    _dateofadmissionController =
        TextEditingController(text: widget.dateofadmission);
    _previouspercentageController =
        TextEditingController(text: widget.previouspercentage);
    _mobilenumberController = TextEditingController(text: widget.mobilenumber);
    _useridController = TextEditingController(text: widget.userid);
    _schoolregidController = TextEditingController(text: widget.schoolregid);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Edit Profile',
        style: TextStyle(
            color: Colors.white, // Set the text color to white
            fontSize: 20, // Adjust the font size if needed
            // fontWeight: FontWeight.bold, // Adjust the font weight if needed
          ),
        ),
        backgroundColor: Colors.deepPurple, // Change the color of the AppBar
        iconTheme: IconThemeData(color: Colors.white),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(' Name:'),
              TextFormField(
                controller: _nameController,
              ),
              SizedBox(height: 20),
              Text(' Email:'),
              TextFormField(
                controller: _emailController,
              ),
              SizedBox(height: 20),
              Text(' Blood Group:'),
              TextFormField(
                controller: _bloodGroupController,
              ),
              SizedBox(height: 20),
              Text(' Father Name:'),
              TextFormField(
                controller: _fathernameController,
              ),
              SizedBox(height: 20),
              Text(' Mother Name:'),
              TextFormField(
                controller: _mothernameController,
              ),
              SizedBox(height: 20),
              Text(' Adhar Number:'),
              TextFormField(
                controller: _adharController,
              ),
              SizedBox(height: 20),
              Text(' Address:'),
              TextFormField(
                controller: _addressController,
              ),
              SizedBox(height: 20),
              Text(' Gender:'),
              TextFormField(
                controller: _genderController,
              ),
              SizedBox(height: 20),
              Text(' Date of Birth:'),
              TextFormField(
                controller: _dobController,
              ),
              SizedBox(height: 20),
              Text(' Occupation:'),
              TextFormField(
                controller: _occupationController,
              ),
              SizedBox(height: 20),
              Text(' Grade:'),
              TextFormField(
                controller: _gradeController,
              ),
              SizedBox(height: 20),
              Text(' Parent Email:'),
              TextFormField(
                controller: _parentemailController,
              ),
              SizedBox(height: 20),
              Text(' Roll Number:'),
              TextFormField(
                controller: _rollnoController,
              ),
              SizedBox(height: 20),
              Text('Place of Birth:'),
              TextFormField(
                controller: _placeofbirthController,
              ),
              SizedBox(height: 20),
              Text('Religion:'),
              TextFormField(
                controller: _religionController,
              ),
              SizedBox(height: 20),
              Text('Caste:'),
              TextFormField(
                controller: _casteController,
              ),
              SizedBox(height: 20),
              Text('Date of Admission:'),
              TextFormField(
                controller: _dateofadmissionController,
              ),
              SizedBox(height: 20),
              Text('Previous Percentage:'),
              TextFormField(
                controller: _previouspercentageController,
              ),
              SizedBox(height: 20),
              Text('Mobile Number:'),
              TextFormField(
                controller: _mobilenumberController,
              ),
              SizedBox(height: 20),
              Text('User ID:'),
              TextFormField(
                controller: _useridController,
              ),
              SizedBox(height: 20),
              Text('School Registration ID:'),
              TextFormField(
                controller: _schoolregidController,
              ),
              SizedBox(height: 20),
              Center(
               child: Row(
                 mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                 children: [
                   ElevatedButton(
                     onPressed: () => _handleAction(_saveProfileChanges, 'Profile Saved Sucessfully'),
                     child: Text('Save Profile'),
                   ),
                   ElevatedButton(
                     onPressed: () => _handleAction(_deleteProfile, 'Profile deleted'),
                     style: ElevatedButton.styleFrom(primary: Color.fromARGB(255, 245, 196, 191)), 
                     child: Text('Delete Profile'),
                   ),
                 ],
               ),
              ),
            ],
          ),
        ),
      ),
    );
  }

    void _deleteProfile() {
    FirebaseFirestore.instance
        .collection('users')
        .where('name', isEqualTo: widget.studentName)
        .get()
        .then((QuerySnapshot querySnapshot) {
      querySnapshot.docs.forEach((doc) {
        doc.reference.delete();
        Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => StudentDetailScreen()),
      );
      });
    });
  }

  void _handleAction(Function action, String message) {
    action();

    // Show a SnackBar to indicate the completion of the action
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        duration: Duration(seconds: 2),
      ),
    );
  }


  void _saveProfileChanges() {
    FirebaseFirestore.instance
        .collection('users')
        .where('name', isEqualTo: widget.studentName)
        .get()
        .then((QuerySnapshot querySnapshot) {
      querySnapshot.docs.forEach((doc) {
        doc.reference.update({
          'name': _nameController.text,
          'email': _emailController.text,
          'bloodgroup': _bloodGroupController.text,
          'fathername': _fathernameController.text,
          'mothername': _mothernameController.text,
          'adhar': _adharController.text,
          'address': _addressController.text,
          'gender': _genderController.text,
          'dob': _dobController.text,
          'occupation': _occupationController.text,
          'grade': _gradeController.text,
          'parentemail': _parentemailController.text,
          'rollno': _rollnoController.text,
          'placeofbirth': _placeofbirthController.text,
          'religion': _religionController.text,
          'caste': _casteController.text,
          'dateofadmission': _dateofadmissionController.text,
          'previouspercentage': _previouspercentageController.text,
          'mobilenumber': _mobilenumberController.text,
          'userid': _useridController.text,
          'schoolregid': _schoolregidController.text,
        });
        Navigator.pop(context);
      });
    });
  }
}
