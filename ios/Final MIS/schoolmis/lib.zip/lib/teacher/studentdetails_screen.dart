import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:schoolmis/teacher/studentprofile.dart';
import 'package:schoolmis/widgets/background_widget.dart';

class StudentDetailScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Student Details',
          style: TextStyle(
            color: Colors.white,
            fontSize: 20,
          ),
        ),
        backgroundColor: Colors.deepPurple,
        iconTheme: IconThemeData(color: Colors.white),
      ),
      body: StudentList(),
    );
  }
}

class StudentList extends StatefulWidget {
  @override
  _StudentListState createState() => _StudentListState();
}

class _StudentListState extends State<StudentList> {
  String selectedClass = '1'; // Default selected class

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance.collection('users').snapshots(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Center(child: CircularProgressIndicator());
        }

        if (!snapshot.hasData) {
          return Center(
            child: Text(
              'Loading...',
              style: TextStyle(fontSize: 24),
            ),
          );
        }

        final students = snapshot.data!.docs;

        // Filter students by grade
        final Map<String, List<Map<String, dynamic>>> studentsByGrade = {};
        students.forEach((doc) {
          final studentData = doc.data() as Map<String, dynamic>;
          final role = studentData['role'];
          final grade = studentData['grade'];

          if (role == 'student' && grade.isNotEmpty) {
            studentsByGrade.putIfAbsent(grade, () => []);
            studentsByGrade[grade]!.add(studentData);
          }
        });

        if (studentsByGrade.isEmpty) {
          return Center(
            child: Text(
              'No students available.',
              style: TextStyle(fontSize: 24),
            ),
          );
        }

        // Sort grades in ascending order
        final sortedGrades = studentsByGrade.keys.toList()
          ..sort((a, b) => int.parse(a).compareTo(int.parse(b)));

        return Column(
          children: [
            DropdownButton<String>(
              value: selectedClass,
              onChanged: (String? newValue) {
                setState(() {
                  selectedClass = newValue!;
                });
              },
              items: sortedGrades.map<DropdownMenuItem<String>>((String grade) {
                return DropdownMenuItem<String>(
                  value: grade,
                  child: Text('Class $grade'),
                );
              }).toList(),
            ),
            Expanded(
              child: ListView(
                children: studentsByGrade[selectedClass]!.map((studentData) {
                  final studentName = studentData['name'];

                  return ListTile(
                    title: GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) =>
                                ProfileScreen(studentName: studentName),
                          ),
                        );
                      },
                      child: Text(
                        studentName ?? "",
                        style: TextStyle(
                          color: Color.fromARGB(255, 0, 0, 0),
                          fontSize: 20,
                        ),
                      ),
                    ),
                  );
                }).toList(),
              ),
            ),
          ],
        );
      },
    );
  }
}
