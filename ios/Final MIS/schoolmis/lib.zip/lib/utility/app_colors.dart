import 'dart:ui';

class AppColors {

  static const primaryColor = Color(0xFF7729EE);
  static const pinkColor = Color(0xFFC822F9);
  static const lightPurpleColor = Color(0xFF855AD1);

}