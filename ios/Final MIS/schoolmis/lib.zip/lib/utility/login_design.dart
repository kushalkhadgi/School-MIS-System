import 'package:flutter/material.dart';

class LoginDesign {
  static BoxDecoration inputBoxDecoration = BoxDecoration(
    color: Colors.white,
    borderRadius: BorderRadius.circular(10),
  );

  static InputDecoration inputDecoration({String labelText = ''}) {
    return InputDecoration(
      labelText: labelText,
      border: InputBorder.none,
    );
  }

  static ButtonStyle loginButtonStyle = ElevatedButton.styleFrom(
    primary: Colors.blue, // Set login button background color
  );

  static ButtonStyle registerButtonStyle = ElevatedButton.styleFrom(
    primary: Colors.green, // Set register button background color
  );
}
