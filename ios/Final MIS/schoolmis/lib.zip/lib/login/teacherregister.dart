import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:schoolmis/login/auth.dart';

class TeacherRegisterPage extends StatelessWidget {
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController nameController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    final auth = Provider.of<AuthProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: Text('Teacher Registration'),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            TextFormField(
              controller: emailController,
              decoration: InputDecoration(labelText: 'Email'),
            ),
            TextFormField(
              controller: passwordController,
              decoration: InputDecoration(labelText: 'Password'),
              obscureText: true,
            ),
            TextFormField(
              controller: nameController,
              decoration: InputDecoration(labelText: 'name'),
            ),
            ElevatedButton(
              onPressed: () async {
                final email = emailController.text;
                final password = passwordController.text;
                final name = nameController.text;
                final user = await auth.register(
                    email: email,
                    password: password,
                    name: name,
                    bloodgroup: '',
                    fathername: '',
                    mothername: '',
                    adhar: '',
                    address: '',
                    gender: '',
                    dob: '',
                    occupation: '',
                    grade: '',
                    parentemail: '',
                    rollno: '',
                    placeofbirth: '',
                    religion: '',
                    caste: '',
                    dateofadmission: '',
                    previouspercentage: '',
                    mobilenumber: '',
                    userid: '',
                    schoolregid: '',
                    isStudent: false);
                if (user != null) {
                  Navigator.pop(context);
                }
              },
              child: Text('Register as Teacher'),
            ),
          ],
        ),
      ),
    );
  }
}
