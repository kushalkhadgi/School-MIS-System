import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:schoolmis/login/auth.dart';
import 'package:intl/intl.dart';

class StudentRegisterPage extends StatelessWidget {
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController nameController = TextEditingController();
  final TextEditingController bloodgroupController = TextEditingController();
  final TextEditingController fathernameController = TextEditingController();
  final TextEditingController mothernameController = TextEditingController();

  final TextEditingController adharController = TextEditingController();
  final TextEditingController addressController = TextEditingController();
  final TextEditingController genderController = TextEditingController();
  final TextEditingController dobController = TextEditingController();
  final TextEditingController occupationController = TextEditingController();
  final TextEditingController gradeController = TextEditingController();
  final TextEditingController parentemailController = TextEditingController();
  final TextEditingController rollnoController = TextEditingController();
  final TextEditingController placeofbirthController = TextEditingController();
  final TextEditingController religionController = TextEditingController();
  final TextEditingController casteController = TextEditingController();
  final TextEditingController dateofadmissionController =
      TextEditingController();
  final TextEditingController previouspercentageController =
      TextEditingController();
  final TextEditingController mobilenumberController = TextEditingController();
  final TextEditingController useridController = TextEditingController();
  final TextEditingController schoolregidController = TextEditingController();
  final DateFormat _dateFormat = DateFormat('dd-MM-yyyy');

  @override
  Widget build(BuildContext context) {
    final auth = Provider.of<AuthProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Student Details',
          style: TextStyle(
            color: Colors.white,
            fontSize: 20,
          ),
        ),
        backgroundColor: Colors.deepPurple,
        iconTheme: IconThemeData(color: Colors.white),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            buildTextField(context, emailController, 'Email'),
            buildTextField(context, passwordController, 'Password', obscureText: true),
            buildTextField(context, nameController, 'Name'),
            buildTextField(context, bloodgroupController, 'Blood Group'),
            buildTextField(context, fathernameController, 'Father\'s Name'),
            buildTextField(context, mothernameController, 'Mother\'s Name'),
            buildTextField(context, adharController, 'Adhar Number'),
            buildTextField(context, addressController, 'Address '),
            buildTextField(context, genderController, 'Gender'),
            buildTextField(context, dobController, 'Date of Birth', readOnly: true),
            // ElevatedButton(
            //   onPressed: () => _selectDate(context),
            //   child: Text('Select Date'),
            // ),
            buildTextField(context, occupationController, 'Occupation'),
            buildTextField(context, gradeController, 'Class'),
            buildTextField(context, parentemailController, 'Parent Email'),
            buildTextField(context, rollnoController, 'Roll No'),
            buildTextField(context, placeofbirthController, 'Place of Birth'),
            buildTextField(context, religionController, 'Religion'),
            buildTextField(context, dateofadmissionController, 'Date of Admission'),
            buildTextField(context, previouspercentageController, 'Previous Percentage'),
            buildTextField(context, mobilenumberController, 'Mobile Number'),
            buildTextField(context, useridController, 'User ID'),
            buildTextField(context, schoolregidController, 'School Registration ID'),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                primary: Colors.deepPurple,
                onPrimary: Colors.white,
                shadowColor: Colors.deepPurpleAccent,
                elevation: 5,
              ),
              onPressed: () async {
                final email = emailController.text;
                final password = passwordController.text;
                final name = nameController.text;
                final bloodgroup = bloodgroupController.text;
                final fathername = fathernameController.text;
                final mothername = mothernameController.text;
                final adhar = adharController.text;
                final address = addressController.text;
                final gender = genderController.text;
                final dob = dobController.text;
                final occupation = occupationController.text;
                final grade = gradeController.text;
                final parentemail = parentemailController.text;
                final rollno = rollnoController.text;
                final placeofbirth = placeofbirthController.text;
                final religion = religionController.text;
                final caste = casteController.text;
                final dateofadmission = dateofadmissionController.text;
                final previouspercentage = previouspercentageController.text;
                final mobilenumber = mobilenumberController.text;
                final userid = useridController.text;
                final schoolregid = schoolregidController.text;

                final user = await auth.register(
                  email: email,
                  password: password,
                  name: name,
                  bloodgroup: bloodgroup,
                  fathername: fathername,
                  mothername: mothername,
                  adhar: adhar,
                  address: address,
                  gender: gender,
                  dob: dob,
                  occupation: occupation,
                  grade: grade,
                  parentemail: parentemail,
                  rollno: rollno,
                  placeofbirth: placeofbirth,
                  religion: religion,
                  caste: caste,
                  dateofadmission: dateofadmission,
                  previouspercentage: previouspercentage,
                  mobilenumber: mobilenumber,
                  userid: userid,
                  schoolregid: schoolregid,
                  isStudent: true,
                );
                if (user != null) {
                  Navigator.pop(context);
                }
              },
              child: Text('Register as Student'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _selectDate(BuildContext context) async {
    DateTime currentDate = DateTime.now();
    DateTime? selectedDate = await showDatePicker(
      context: context,
      initialDate: currentDate,
      firstDate: DateTime(1900),
      lastDate: DateTime.now(),
    );

    if (selectedDate != null && selectedDate != currentDate) {
      dobController.text = _dateFormat.format(selectedDate);
    }
  }

  Widget buildTextField(
    BuildContext context,
    TextEditingController controller,
    String labelText, {
    bool obscureText = false,
    bool readOnly = false,
  }) {
    return Container(
      margin: EdgeInsets.only(bottom: 16.0),
      child: TextFormField(
        controller: controller,
        obscureText: obscureText,
        readOnly: readOnly,
        onTap: readOnly ? () => _selectDate(context) : null,
        decoration: InputDecoration(
          labelText: labelText,
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(15.0),
            borderSide: BorderSide.none,
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(15.0),
            borderSide: BorderSide(color: Colors.deepPurple),
          ),
          labelStyle: TextStyle(color: Colors.deepPurple),
          focusColor: Colors.deepPurple,
          hoverColor: Colors.deepPurple,
          contentPadding:
              EdgeInsets.symmetric(horizontal: 24.0, vertical: 20.0),
          isDense: true,
          errorStyle: TextStyle(color: Colors.redAccent),
        ),
      ),
    );
  }
}
